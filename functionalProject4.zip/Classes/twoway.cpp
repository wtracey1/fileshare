#include <iostream>
#include <cmath>
#include "twoway.h"

Twoway::Twoway( cocos2d::Layer* p, const std::string name, const float lx, const float ly) : 
  Base( p ),
  sprite( cocos2d::Sprite::create(name) ),
  size( sprite->getContentSize().width, sprite->getContentSize().height )
{
  getParentLayer()->addChild(sprite);
  sprite->setPosition( cocos2d::Point(lx, ly) ); 
  sprite->setScaleX(1.0);
}

Twoway::Twoway( cocos2d::Layer* p, const std::string name, const float lx, const float ly, const float vx, const float vy) : 
  Base( vx, vy, p ),
  sprite( cocos2d::Sprite::create(name) ),
  size( sprite->getContentSize().width, sprite->getContentSize().height )
{
  getParentLayer()->addChild(sprite);
  sprite->setPosition( cocos2d::Point(lx, ly) ); 
  sprite->setScaleX(vx>=0?1.0:-1.0);
}

void Twoway::update(float dt) {
  auto position = sprite->getPosition();
  cocos2d::Vec2 incr = getVelocity() * dt;
  sprite->setPosition(position.x + incr.x, position.y + incr.y );

  cocos2d::Point location = sprite->getPosition();
  if ( location.x > getViewSize().width - size.x/2 ) {
    VelX( -abs(VelX()) ); 
    sprite->setScaleX(-1.0);

  }
  if ( location.x < size.x/2 ) {
    VelX( abs(VelX()) ); 
    sprite->setScaleX(1.0);
  }
}

float Twoway::getDistance( const Base* b ) const {
  return sprite->getPosition().distanceSquared(b->getPos());
}
