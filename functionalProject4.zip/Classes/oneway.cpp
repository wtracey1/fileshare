#include <iostream>
#include <cmath>
#include "oneway.h"

Oneway::Oneway( cocos2d::Layer* p, const std::string name, const float lx, const float ly) : 
  Base( p ),
  sprite( cocos2d::Sprite::create(name) ),
  size( sprite->getContentSize().width, sprite->getContentSize().height )
{
  getParentLayer()->addChild(sprite, 1);
  sprite->setPosition( cocos2d::Point(lx, ly) ); 
}

Oneway::Oneway( cocos2d::Layer* p, const std::string name, const float lx, const float ly, const float vx, const float vy) : 
  Base( vx, vy, p ),
  sprite( cocos2d::Sprite::create(name) ),
  size( sprite->getContentSize().width, sprite->getContentSize().height )
{
  getParentLayer()->addChild(sprite, 1);
  sprite->setPosition( cocos2d::Point(lx, ly) ); 
}

void Oneway::update(float dt) {
  auto position = sprite->getPosition();
  cocos2d::Vec2 incr = getVelocity() * dt;
  sprite->setPosition(position.x + incr.x, position.y + incr.y );

  cocos2d::Point location = sprite->getPosition();
  if ( location.x > getViewSize().width + size.x/2 ) {
    sprite->setPosition(-size.x/2, position.y );
  }
  if ( location.x < -size.x/2 ) {
    sprite->setPosition(getViewSize().width + size.x/2, position.y );
  }  
  if ( location.y > getViewSize().height + size.x/2 ) {
    sprite->setPosition(position.x, -size.x/2 );
  }  
  if ( location.y < -size.x/2 ) {
    sprite->setPosition(position.x, getViewSize().height + size.x/2 );
  }  
}

float Oneway::getDistance( const Base* b ) const {
  return sprite->getPosition().distanceSquared(b->getPos());
}