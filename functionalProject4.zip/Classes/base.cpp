#include <iostream>
#include <cmath>
#include "base.h"

Base::Base( cocos2d::Layer* p ) : 
  velocity( 0, 0 ),
  viewSize( cocos2d::Director::getInstance()->getVisibleSize() ),
  origin( cocos2d::Director::getInstance()->getVisibleOrigin() ),
  parent(p)
{
}

Base::Base(float x, float y, cocos2d::Layer* p ) : 
  velocity( x, y ),
  viewSize( cocos2d::Director::getInstance()->getVisibleSize() ),
  origin( cocos2d::Director::getInstance()->getVisibleOrigin() ),
  parent(p)
{
}

