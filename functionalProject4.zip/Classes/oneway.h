#ifndef ONEWAY__H
#define ONEWAY__H
#include "cocos2d.h"
#include "base.h"
#include <cstring>

/*
 *  Oneway sprite will cross the viewport while touch the boundary.
 *
 */

class Oneway : public Base {
public:
  Oneway(cocos2d::Layer* p, const std::string name, const float lx, const float ly);
  Oneway(cocos2d::Layer* p,const std::string name, const float lx, const float ly, const float vx, const float vy);
  virtual ~Oneway() { /*delete sprite;*/ getParentLayer()->removeChild(sprite); }
  void virtual update(float);
  cocos2d::Sprite* getSprite() const { return sprite; }
    
  float getDistance( const Base* b ) const ;
  cocos2d::Vec2 getPos() const { return sprite->getPosition(); }
  bool isexplode() { return false; }
private:
  cocos2d::Sprite* sprite;
  cocos2d::Vec2 size;
};
#endif
