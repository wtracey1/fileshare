#ifndef TWOWAY__H
#define TWOWAY__H
#include "cocos2d.h"
#include "base.h"
#include <cstring>


/*
 *  Twoway sprite will flip herizontally while touch the boundary.
 *
 */

class Twoway : public Base {
public:
  	Twoway( cocos2d::Layer* p, const std::string name, const float lx, const float ly);
  	Twoway( cocos2d::Layer* p, const std::string name, const float lx, const float ly, const float vx, const float vy);
  	virtual ~Twoway() { /*delete sprite;*/ getParentLayer()->removeChild(sprite); }
  	void virtual update(float);
  	cocos2d::Sprite* getSprite() const { return sprite; }
    
    float getDistance( const Base* b ) const ;
  	cocos2d::Vec2 getPos() const { return sprite->getPosition(); }
  	bool isexplode() { return false; }
private:
  	cocos2d::Sprite* sprite;
  	cocos2d::Vec2 size;
};
#endif
