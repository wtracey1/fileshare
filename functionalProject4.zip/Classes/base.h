#ifndef BASE__H
#define BASE__H
#include "cocos2d.h"

/*
 *  This is the base class with vel, viewsize, originpos
 *  and parent layer pointer ( we can get position from
 *  cocos2d::sprite). 
 */

class Base {
public:
    Base( cocos2d::Layer* );
  	Base(float, float, cocos2d::Layer* );
  	virtual ~Base() {};

  	cocos2d::Vec2 getVelocity() const { return velocity; }
  	void setVelocity( const cocos2d::Vec2& v ) { velocity.set(v); }
  	float VelX() { return velocity.x; }
  	void VelX( float x ) { velocity.x = x; }
  	float VelY() { return velocity.y; }
  	void VelY( float y ) { velocity.y = y; }
  	
  	cocos2d::Size getViewSize() const { return viewSize; }

  	virtual void update(float) = 0;  	
  	virtual cocos2d::Sprite* getSprite() const = 0;
  	virtual float getDistance( const Base* b ) const = 0;
  	virtual cocos2d::Vec2 getPos() const = 0;
  	virtual bool isexplode() = 0;
    cocos2d::Layer* getParentLayer() { return parent; }
    
private:
  	cocos2d::Vec2 velocity;
  	cocos2d::Size viewSize;
  	cocos2d::Point origin;
    cocos2d::Layer* parent; 
};
#endif
