#ifndef EXP__H
#define EXP__H
#include "cocos2d.h"
#include "oneway.h"
#include "chunk.h"
#include <cstring>
#include <list>

/*
 *  Exp is the sprite that could explode.
 *  Using object pool manages chunks.
 *  This is a simple version. It has a timer to explode 
 *  every 1s. It seperate the car sprite into 16 pieces.
 *  
 *   
 */

class Exp : public Oneway {
public:
  	Exp( cocos2d::Layer* p, const std::string name, const float lx, const float ly );
  	Exp( cocos2d::Layer* p, const std::string name, const float lx, const float ly, const float vx, const float vy );
  	virtual ~Exp() { /*delete sprite;*/ }
  	void virtual update(float);
  	cocos2d::Sprite* getSprite() const { return Oneway::getSprite(); }
    
  	float getDistance( const Base* b ) const ;
  	cocos2d::Vec2 getPos() const { return Oneway::getPos(); }
    void makechunks();
    void resetshowlist();
    bool isexplode() { return explode; }
private:
	std::list<Base*> showlist;
  std::list<Base*> freelist;
  float count;
	bool explode;
};
#endif
