#ifndef __CARTRAFIC__
#define __CARTRAFIC__

#include "cocos2d.h"
#include "base.h"
#include <list>

class CarTrafic : public cocos2d::Layer
{
public:
  CarTrafic();
  ~CarTrafic(); 
  static cocos2d::Scene* createScene();
  virtual bool init();
  void update(float);
    
  // a selector callback
  void menuCloseCallback(cocos2d::Ref* pSender);
    
  // implement the "static create()" method manually
  CREATE_FUNC(CarTrafic);

private:

  std::list<Base*> l;

  cocos2d::Size visibleSize;
  cocos2d::Point origin;
  int starWidth;
};

#endif // __CARTRAFIC__
