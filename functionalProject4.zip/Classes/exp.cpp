#include <iostream>
#include <cmath>
#include "exp.h"

Exp::Exp( cocos2d::Layer* p, const std::string name, const float lx, const float ly ) : 
	Oneway( p, name, lx, ly ),
	showlist(),
	freelist(),
	count(0),
	explode(false)
{ 
}

Exp::Exp( cocos2d::Layer* p, const std::string name, const float lx, const float ly, const float vx, const float vy ) :
	Oneway( p, name, lx, ly, vx, vy ),
	showlist(),
	freelist(),
	count(0),
	explode(false)
{ 
}

void Exp::update(float dt) {
	if(count<1 && !explode){
		count+=dt;
		Oneway::update(dt);
	}else if(count>1 && !explode){
		explode = true;
		makechunks();	// should explode.
	}else{
		if(showlist.size()==0){
			count = 0;
			explode = false;
			getParentLayer()->addChild(getSprite()); 
			getSprite()->release();
		}
		
		auto ptr = showlist.begin();
		while(ptr!=showlist.end()){
			(*ptr)->update(dt);
			if(this->getDistance(*ptr) > 10000){
				(*ptr)->getSprite()->retain();
				getParentLayer()->removeChild((*ptr)->getSprite()); 
				freelist.push_back((*ptr));
				ptr = showlist.erase(ptr);
			}else	++ptr;
		}
	}
}


float Exp::getDistance( const Base* b ) const {
	return Oneway::getDistance(b);
}

void Exp::makechunks(){
	getSprite()->retain();	// un-display the car sprite
	getParentLayer()->removeChild(getSprite()); 

	// When new a chunk, constructor will call addChild.
	// Otherwise, we will addChild at here.
	if(freelist.size()>0){		
		auto ptr = freelist.begin();
		while(ptr!=freelist.end()){
			getParentLayer()->addChild((*ptr)->getSprite(), 1); 
			(*ptr)->getSprite()->release();
			showlist.push_back(*ptr);
			ptr=freelist.erase(ptr);
		}
	}
	else{
		for(int i=0;i<4;i++){
			for(int j=0;j<4;j++){
				showlist.push_back(new Chunk( getParentLayer(), "car2.png", getPos().x, getPos().y, 100, 100, i*15, j*8, 15, 8));
			}
		}
	}
	resetshowlist();
}

// Reset position and velocity.
// Compute velocity range [150, 250] in random angle.
void Exp::resetshowlist(){
	float px = getPos().x;
	float py = getPos().y;

	auto ptr = showlist.begin();
	int i=0,j=0;
	int basespeed = 200;
	int flospeed = 100;
	float theta;
	int up;

	while (ptr != showlist.end()){
		theta = rand()%360* (M_PI) / 360;
		float temp = basespeed + rand()%flospeed - flospeed/2;
		up = rand()%2?1:-1;
		(*ptr)->setVelocity(cocos2d::Vec2(up*temp * cos(theta), up*temp*sin(theta)));	
		(*ptr)->getSprite()->setPosition(cocos2d::Vec2(px-15*(4-2*i-1)/8, py+8*(4-2*j-1)/8));
		i=(i+1)%4;
		if(i==0) j++;
		++ptr;
	}
}